package package1;

public class User extends Person {

	public User(String pname, String pphone) {
		super(pname, pphone);
		// TODO Auto-generated constructor stub
	}

}
