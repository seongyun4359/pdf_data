package package1;

public class AdminUser {
	String id="Admin";
	String pw="Admin1234";
	String name;
	String phone;
	boolean login_state=false;

	public AdminUser(String pname, String pphone) {
		this.name=pname;
		this.phone=pphone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getId() {
		return id;
	}

	public String getPw() {
		return pw;
	}
	
	public void login() {
		this.login_state=true;
	}
	
	public void logout() {
		this.login_state=false;
	}
	
	public boolean isLogin() {
		return this.login_state;
	}

}
