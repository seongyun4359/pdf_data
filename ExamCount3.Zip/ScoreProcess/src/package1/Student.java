package package1;

public class Student {
	private String id;
	private String name;
	private String phone;
	private int kor=0;
	private int eng=0;
	private int mat=0;
		

	public Student(String pid, String pname, String pphone) {
		this.id=pid;
		this.name=pname;
		this.phone=pphone;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMat() {
		return mat;
	}

	public void setMat(int mat) {
		this.mat = mat;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

}
