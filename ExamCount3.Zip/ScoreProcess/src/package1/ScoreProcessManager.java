package package1;

import java.util.Scanner;

public class ScoreProcessManager {
	private MenuManager menuMng = null;
	private Student[] stuList = null;
	private AdminUser admin = null;
	private int completeStuCount=0;
	private final int STU_COUNT=3;
	
	public ScoreProcessManager() {
		this.menuMng = new MenuManager();
		stuList = new Student[] { new Student("aa", "aaa", "55555555"), new Student("bb", "bbb", "77777777"),
				new Student("cc", "ccc", "88888888") };
	}

	public void run() {

		while (true) {
			boolean end_flag = false;
			this.menuMng.initMenu();
			int select = this.menuMng.selectInitMenu();
			switch (select) {
			case MenuManager.ADMIN_LOGIN:
				if (this.adminLogin()) {
					this.scoreProcess();
				}
				break;
			case MenuManager.EXIT:
				end_flag = true;
				break;
			}
			if (end_flag) {
				break;
			}
		}

	}
	
	public boolean adminLogin() {
		Scanner input=new Scanner(System.in);
		System.out.print("Name:");
		String name=input.nextLine();
		System.out.print("Phone:");
		String phone=input.nextLine();
		
		this.admin=new AdminUser(name, phone);
		
		System.out.print("ID:");
		String id=input.nextLine();
		System.out.print("PW:");
		String pw=input.nextLine();
		
		if(admin.getId().equals(id) && admin.getPw().equals(pw)) {
			System.out.println(admin.getName()+"관리자님 반갑습니다.");
			return true;
		}
		else {
			System.out.println("관리자 계정이 틀렸습니다");
			return false;
		}	
	}
	
	public void scoreProcess() {
		while(true) {
			boolean end_flag=false;
			this.menuMng.ScoreMenu();
			int select=this.menuMng.selectScoreMenu();
			switch(select) {
			case MenuManager.INPUT_SCORE:
				this.inputScore();
				break;
			case MenuManager.SEARCH_SCORE:
				this.searchScore();
				break;
			case MenuManager.SEARCH_ALL_SCORE:
				this.searchAllScore();	
				break;
			case MenuManager.LOGOUT:
				this.logout();
				end_flag=true;
				break;
			}			
			if(end_flag) {
				break;
			}				
		}		
	}
	
	public void inputScore() {
		Scanner input=new Scanner(System.in);
		for(int i=0; i<this.STU_COUNT; i++) {
			System.out.println("ID: "+this.stuList[i].getId()+" NAME: "+ this.stuList[i].getName());
			System.out.print("국어:");
			int temp=input.nextInt();
			input.nextLine();
			this.stuList[i].setKor(temp);
			
			System.out.print("영어:");
			temp=input.nextInt();
			input.nextLine();
			this.stuList[i].setEng(temp);
			
			System.out.print("수학:");
			temp=input.nextInt();
			input.nextLine();
			this.stuList[i].setMat(temp);
			this.completeStuCount++;
			
			System.out.println("계속 입력하시겠습니까?? Y  | N ");
			String str = input.nextLine();
			if (!str.toUpperCase().equals("Y")) {
				break;
			}
			if(i==this.STU_COUNT-1) {
				System.out.println("모든학생의 입력이 끝났습니다.");
			}
		}
	}
	
	public void searchScore() {
		Scanner input=new Scanner(System.in);
		System.out.print("검색할 학생의 학번:");
		String id=input.nextLine();
		boolean flag=false;
		for(int i=0; i<this.completeStuCount; i++) {
			if(this.stuList[i].getId().equals(id)) {
				System.out.println("ID: "+this.stuList[i].getId());
				System.out.println("Name: "+this.stuList[i].getName());
				System.out.println("국어: "+this.stuList[i].getKor());
				System.out.println("영어: "+this.stuList[i].getEng());
				System.out.println("수학: "+this.stuList[i].getMat());
				int tot=this.stuList[i].getKor()+this.stuList[i].getEng()+this.stuList[i].getMat();
				System.out.println("총점: "+tot);
				double avg=tot/3.0;
				System.out.println("평균: "+avg);		
				flag=true;
			}
		}
		
		if(!flag) {
			System.out.println("입력하신 학번의 학생이 없거나 아직 성적이 입력ㄷ되지 않았습니다.");
		}		
	}
	
	public void searchAllScore() {
		for(int i=0; i<this.completeStuCount; i++) {
			System.out.println("ID: "+this.stuList[i].getId());
			System.out.println("Name: "+this.stuList[i].getName());
			System.out.println("국어: "+this.stuList[i].getKor());
			System.out.println("영어: "+this.stuList[i].getEng());
			System.out.println("수학: "+this.stuList[i].getMat());
			int tot=this.stuList[i].getKor()+this.stuList[i].getEng()+this.stuList[i].getMat();
			System.out.println("총점: "+tot);
			double avg=tot/3.0;
			System.out.println("평균: "+avg);		
		}	
	}
	
	public void logout() {
		this.admin.logout();
		this.admin=null;
	}	
	
}


