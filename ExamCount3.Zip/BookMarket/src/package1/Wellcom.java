package package1;

public class Wellcom {	

	public static void main(String[] args) {
		BookMarketManager manager=new BookMarketManager();
		manager.run();
	}
	
}


