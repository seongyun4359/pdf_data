package package1;

import java.util.Scanner;

public class AddressManager {
	MenuManager menuMng=null;
	User[] userList=null;
	User curUser=null;
	
	public AddressManager() {
		this.menuMng=new MenuManager();
		userList=new User[] {new User("aaa","aa","11", "55555555", "서울"),
				new User("bbb","bb","22", "77777777", "경기"),
				new User("ccc","cc","33", "88888888", "부산")};
	}
	
	public void run() {
		
		while(true) {
			boolean end_flag=false;
			this.menuMng.initMenu();
			int select=this.menuMng.selectInitMenu();
			switch(select) {
			case MenuManager.LOGIN:
				if(this.loginProcess()){
					this.addressProcess();
				}				
				break;
			case MenuManager.EXIT:
				end_flag=true;
				break;				
			}
			if(end_flag) {
				break;
			}
		}
		
	}
	
	public boolean loginProcess() {
		Scanner input=new Scanner(System.in);
		System.out.print("ID:");
		String id=input.nextLine();
		System.out.print("PW:");
		String pw=input.nextLine();
		
		for(int i=0;i<this.userList.length; i++) {
			if(this.userList[i].getId().equals(id) && 
					this.userList[i].getPw().equals(pw)) {
			  this.userList[i].setLogin();	
			  this.curUser=this.userList[i];
			  break;
			}
		}
		if(curUser!=null) {
			return true;
		}			
		return false;
	}
	
	public void addressProcess() {
		while(true) {
			boolean end_flag=false;
			this.menuMng.addressMenu();
			int select=this.menuMng.selectAddressMenu();
			switch(select) {
			case MenuManager.ADDRESS_SEARCH:
				this.addressSearch();
				break;
			case MenuManager.ALL_ADDRESS_SEARCH:
				this.allAddressSearch();
				break;
			case MenuManager.LOGOUT:
				this.logout();
				end_flag=true;
				break;
			}			
			if(end_flag) {
				break;
			}				
		}		
	}
	
	public void addressSearch() {
		Scanner input=new Scanner(System.in);
		System.out.print("검색할 유저의 이름:");
		String name=input.nextLine();
		for(int i=0; i<this.userList.length; i++) {
			if(this.userList[i].getName().equals(name)) {
				System.out.println(name+"님의 주소: "+this.userList[i].getAddress());
				System.out.println(name+"님의 전화번호: "+this.userList[i].getPhone());
			}
		}
	}
	
	public void allAddressSearch() {
		for(int i=0; i<this.userList.length; i++) {
			System.out.println(this.userList[i].getName()+"님의 주소: "+this.userList[i].getAddress());
			System.out.println(this.userList[i].getName()+"님의 전화번호: "+this.userList[i].getPhone());
		}		
	}
	
	public void logout() {
		this.curUser.logout();
		this.curUser=null;
	}
}
