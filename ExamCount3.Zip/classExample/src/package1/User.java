package package1;

public class User {
	private String name;
	private String id;
	private String pw;
	private String phone;
	private String address;
	private boolean login_state;
	
	public User(String pname, String pid, String ppw, String pphone, String paddress) {
		this.name=pname;
		this.id=pid;
		this.pw=ppw;
		this.phone=pphone;
		this.address=paddress;		
		this.login_state=false;
	}
	
	public boolean isLogin() {
		return this.login_state;
	}
	
	public void setLogin() {
		this.login_state=true;
	}
	public void logout() {
		this.login_state=false;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
}
