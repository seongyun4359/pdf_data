package package1;

public class App {

	public static void main(String[] args) {
		AddressManager manager=new AddressManager();
		manager.run();

	}

}
